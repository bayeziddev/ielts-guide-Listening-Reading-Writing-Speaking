# IELTS Guide Pro

A comprehensive, article-based IELTS preparation course built with **SmartGenDocs**.

Live site (after deploy): https://ielts-guide.smartgentools.com/

## Modules

- **Listening** – test format, question types, strategies, common mistakes, samples
- **Reading** – techniques, MCQ, TFNG, matching, completion tasks
- **Writing** – Task 1 Academic / General, Task 2 essays, band descriptors, model answers
- **Speaking** – Part 1/2/3, fluency, vocabulary, pronunciation, sample responses

## Quick Start (local)

```bash
# 1. Install the SmartGenDocs engine
pip install "git+https://github.com/bayeziddev/smartGenDocs.git"

# 2. Build the site
smartgen build --config smartgen.yml --site-dir site

# 3. Serve locally (optional)
cd site && python -m http.server 8000
```

## Authentication / Python API (conceptual)

SmartGenDocs documents a future API. The recommended authentication header is:

```
X-API-Key: YOUR_API_KEY
```

See the official reference:  
https://docs.smartgentools.com/api/authentication.html

A minimal Python client that follows that pattern is available in `scripts/smartgen_client.py`.

## Configuration

All navigation and theme settings live in `smartgen.yml`.  
Theme: `premium` with academic blue + education amber palette.

## Author

Sayad Md Bayezid Hosan  
SmartGen Tools – https://www.smartgentools.com
