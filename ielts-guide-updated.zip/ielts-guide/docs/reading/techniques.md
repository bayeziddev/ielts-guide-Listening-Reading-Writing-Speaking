# Reading Techniques – Skimming & Scanning

## Skimming

Skimming means reading quickly to get the **main idea** of a paragraph or the whole passage.

- Read the title, headings and first sentence of each paragraph.
- Look for topic sentences (usually the first or last sentence of a paragraph).
- Do not stop for unknown words during the first pass.

## Scanning

Scanning means looking for **specific information** (names, numbers, dates, keywords).

- Underline or highlight the key words in the question.
- Move your eyes rapidly over the text until you find those words or their synonyms.
- Read the surrounding sentences carefully to confirm the answer.

## Matching Headings Strategy

1. Read all the headings first and underline keywords.
2. Skim each paragraph for its main idea.
3. Match the clearest ones first and leave difficult ones until the end.
4. Cross out used headings so you do not reuse them.

These two techniques together form the foundation of efficient IELTS Reading. Practise them on every Cambridge past paper until they become automatic.
