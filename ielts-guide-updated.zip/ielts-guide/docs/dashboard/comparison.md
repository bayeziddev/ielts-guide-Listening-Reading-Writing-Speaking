# Academic vs General Training\n\nWhich version should you take?

This page is part of the IELTS Guide Pro course. Detailed content, strategies, examples and practice tips will continue to be expanded in upcoming updates.

For the latest official information always refer to the British Council / IDP / Cambridge IELTS materials.
