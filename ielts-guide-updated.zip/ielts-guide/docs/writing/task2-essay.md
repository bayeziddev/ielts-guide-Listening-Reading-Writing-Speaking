# IELTS Writing Task 2 – Essay Guide

Task 2 is worth twice as many marks as Task 1. You should spend about 40 minutes on it and write at least 250 words.

## Common Question Types

- Opinion (Agree / Disagree)
- Discussion (Discuss both views + opinion)
- Advantages & Disadvantages
- Problem & Solution
- Two-part questions

## Recommended Structure (4–5 paragraphs)

1. **Introduction** – paraphrase the question + clear thesis statement.
2. **Body Paragraph 1** – main idea + explanation + example.
3. **Body Paragraph 2** – second main idea + explanation + example.
4. **(Optional) Body Paragraph 3** – if the question requires three points.
5. **Conclusion** – summarise and restate your position (no new ideas).

## Band 7+ Language Tips

- Use a range of complex sentences (conditionals, relative clauses, passive).
- Avoid repeating the same words; use precise academic vocabulary and synonyms.
- Link ideas with cohesive devices (However, Furthermore, As a result, In contrast).
- Stay on topic and fully address every part of the question.

Always leave 3–4 minutes at the end to check grammar, spelling and word count.
