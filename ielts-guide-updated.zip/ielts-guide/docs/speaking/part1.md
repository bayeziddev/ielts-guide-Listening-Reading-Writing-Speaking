# IELTS Speaking Part 1

Part 1 lasts 4–5 minutes and covers familiar topics (home, work/study, hobbies, daily routines).

## Strategy

- Answer in 2–4 full sentences. Avoid one-word replies.
- Expand with a reason or short example.
- Use a mix of simple and complex structures naturally.
- Keep your answers relevant; do not memorise long scripts.

## Sample Topics

- Hometown / accommodation
- Work or studies
- Free time and hobbies
- Food, travel, technology, friends

Practise answering the same question in different ways so you sound spontaneous on the day.
