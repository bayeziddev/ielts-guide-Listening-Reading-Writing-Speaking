# Common Mistakes in IELTS Listening

| Mistake | Why it happens | How to avoid |
| :--- | :--- | :--- |
| Exceeding the word limit | Candidates write full sentences instead of the required words | Always check the instruction box |
| Spelling errors | Unfamiliar names or technical terms | Practise spelling of common IELTS vocabulary |
| Losing the sequence | Focusing too long on a missed answer | Move on immediately; guess later if needed |
| Not transferring answers | Running out of time at the end of paper-based tests | Practise the 10-minute transfer under timed conditions |
| Ignoring plurals | Hearing “books” but writing “book” | Listen carefully for the final /s/ or /z/ sound |
| Changing the form of the word | Writing a noun when a verb is needed | Make sure the answer fits the grammar of the sentence |

The single most effective way to reduce these errors is to review every practice test carefully and keep a personal error log.
