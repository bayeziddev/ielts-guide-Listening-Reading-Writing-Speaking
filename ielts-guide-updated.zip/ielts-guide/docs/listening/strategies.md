# Effective Listening Strategies for IELTS

## Before the Recording Starts

1. **Read the questions carefully** (you usually have 30–45 seconds).
2. **Underline keywords** and predict the type of answer (name, number, place, opinion).
3. **Note the word limit** for completion tasks.

## During the Recording

- Listen for **signpost language** (“firstly”, “however”, “the main reason is…”).
- Accept that you will miss some answers. Move on immediately so you do not lose the next question.
- Write answers clearly on the question paper first; transfer them carefully later (paper test) or type carefully (computer test).

## Spelling & Grammar

- Names of people and places are usually spelled out the first time they appear.
- American and British spellings are both accepted if consistent, but prefer the spelling used in the recording.
- Plurals and verb forms must be grammatically correct for the sentence.

## Common Score Killers

- Writing more words than allowed.
- Changing the meaning by using the wrong part of speech.
- Losing concentration in Section 4 (academic monologue).

Practice with timed full tests at least twice a week in the final month before your exam.
