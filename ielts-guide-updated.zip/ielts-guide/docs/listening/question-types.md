# IELTS Listening – Common Question Types

The Listening paper contains a mixture of question types. Knowing the exact task requirements in advance saves valuable seconds during the recording.

## 1. Multiple Choice (MCQ)

- You choose the correct letter (A, B or C) or the correct option from a longer list.
- Sometimes more than one answer is required (e.g. “Choose TWO letters”).
- Tip: Underline key words in the question stem before the audio starts. Listen for synonyms and paraphrases, not exact wording.

## 2. Matching

- You match a list of items (people, places, features) from the box to statements or questions.
- Often appears in Section 1 or Section 2 (maps, plans, or speaker opinions).
- Tip: Cross out options as you use them to avoid re-using the same letter.

## 3. Form / Note / Table / Flow-chart Completion

- Fill in missing information from a form, set of notes, table or process diagram.
- Usually limited to one, two or three words and/or a number.
- Tip: Pay close attention to the word limit. “NO MORE THAN TWO WORDS AND/OR A NUMBER” is the most common instruction.

## 4. Sentence Completion

- Complete a sentence with a short phrase from the recording.
- Grammar must fit the sentence; spelling must be accurate.
- Tip: Predict the type of information (noun, verb, number) before listening.

## 5. Short-answer Questions

- Answer questions with a limited number of words.
- Similar rules to completion tasks regarding word limits.

## 6. Map / Plan / Diagram Labelling

- Label places or features on a visual using words from the recording or a list of options.
- Common in Section 2.
- Tip: Familiarise yourself with the layout and the direction language (north, opposite, next to, etc.) before the audio begins.

Practice each type regularly with official Cambridge IELTS past papers. Accuracy of spelling and adherence to word limits are as important as understanding the audio.
