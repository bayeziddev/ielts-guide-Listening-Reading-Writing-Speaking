"""
Conceptual SmartGenDocs Python client following the official authentication docs.
https://docs.smartgentools.com/api/authentication.html
"""

from __future__ import annotations

import os
from typing import Any, Optional

import requests


class SmartGenDocsClient:
    """Minimal client that uses X-API-Key authentication."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: str = "https://api.smartgendocs.com/v1",
    ) -> None:
        self.api_key = api_key or os.environ.get("SMARTGENDOCS_API_KEY")
        if not self.api_key:
            raise ValueError(
                "API key required. Set SMARTGENDOCS_API_KEY environment variable "
                "or pass api_key=..."
            )
        self.base_url = base_url.rstrip("/")
        self.session = requests.Session()
        self.session.headers.update(
            {
                "X-API-Key": self.api_key,
                "Content-Type": "application/json",
                "User-Agent": "SmartGenDocs-Python-Client/0.1",
            }
        )

    def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        url = f"{self.base_url}/{path.lstrip('/')}"
        resp = self.session.request(method, url, **kwargs)
        resp.raise_for_status()
        if resp.content:
            return resp.json()
        return {}

    def get_status(self) -> dict[str, Any]:
        """GET /status"""
        return self._request("GET", "/status")

    def trigger_build(self) -> dict[str, Any]:
        """POST /build"""
        return self._request("POST", "/build")

    def get_document_content(
        self, page_path: str, format: str = "html"
    ) -> str:
        """GET /docs/{page_path}?format=..."""
        resp = self.session.get(
            f"{self.base_url}/docs/{page_path}",
            params={"format": format},
        )
        resp.raise_for_status()
        return resp.text


if __name__ == "__main__":
    # Example usage (requires a real key and live API)
    try:
        client = SmartGenDocsClient()
        print(client.get_status())
    except Exception as exc:
        print(f"Client demo (API not yet live): {exc}")
